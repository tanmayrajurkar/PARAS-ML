import serial
import time
import cv2
from ultralytics import YOLO
from supabase import create_client
import pytesseract

# Initialize Supabase
SUPABASE_URL = "https://ipmshfkymnflueddojcw.supabase.co"
SUPABASE_API_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImlwbXNoZmt5bW5mbHVlZGRvamN3Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3MzE5NDU0NzAsImV4cCI6MjA0NzUyMTQ3MH0.CIAqAEJ_aV5OIbyCKEShSljutfYdmGR67tvpVgO1gUc"
supabase = create_client(SUPABASE_URL, SUPABASE_API_KEY)

# Initialize Serial Connection to Arduino
arduino = serial.Serial('COM5', 9600, timeout=1)  # Replace with your Arduino port

# Load YOLO models
model_plate = YOLO(r"D:\Integration\NUMBER PLATE MODEL\roboflow\runs\detect\train\weights\best.pt")  # Number plate detection model
model_car = YOLO(r"D:\Integration\CAR MODEL\runs\detect\train\weights\best.pt")  # Car detection model

# Function to detect number plates
def detect_number_plate():
    cap_plate = cv2.VideoCapture(0)  # Webcam for number plate detection
    if not cap_plate.isOpened():
        print("Webcam 1 (Number Plate Detection) failed to open.")
        return False

    while True:
        ret, frame = cap_plate.read()
        if not ret:
            print("Failed to capture frame from Webcam 1.")
            break

        results_plate = model_plate.predict(source=frame, show=True, conf=0.5)
        for result in results_plate:
            for box in result.boxes:
                x1, y1, x2, y2 = map(int, box.xyxy[0])
                cropped_plate = frame[y1:y2, x1:x2]

                plate_text = pytesseract.image_to_string(cropped_plate, config="--psm 7").strip()
                if plate_text:
                    print(f"Detected Plate: {plate_text}")
                    cap_plate.release()
                    cv2.destroyAllWindows()
                    return True

        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    cap_plate.release()
    cv2.destroyAllWindows()
    return False

# Function to detect cars in parking slots
def detect_car_in_slot():
    cap_car = cv2.VideoCapture(1)  # Webcam for car detection
    if not cap_car.isOpened():
        print("Webcam 2 (Car Detection) failed to open.")
        return False

    print("Webcam 2 is now active for car detection.")
    while True:
        ret, frame = cap_car.read()
        if not ret:
            print("Failed to capture frame from Webcam 2.")
            break

        results = model_car.predict(source=frame, show=True, conf=0.5)
        car_detected = False
        for result in results:
            boxes = result.boxes
            class_ids = boxes.cls

            for i in range(len(boxes)):
                if result.names[int(class_ids[i])] == 'car' and boxes.conf[i] > 0.5:
                    car_detected = True
                    break

        if car_detected:
            cv2.putText(frame, "Car Detected", (50, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
            print("Car Present in the Slot")
        else:
            cv2.putText(frame, "No Car Detected", (50, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)
            print("No Car in the Slot")

        cv2.imshow('Car Detection', frame)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    cap_car.release()
    cv2.destroyAllWindows()
    return True

# Main function
if __name__ == "__main__":
    # Step 1: Detect number plates
    print("Starting number plate detection...")
    plate_detected = detect_number_plate()

    if plate_detected:
        print("Number plate detection complete. Switching to car detection...")
        # Step 2: Detect cars in parking slots
        detect_car_in_slot()
    else:
        print("Number plate detection failed. Car detection will not proceed.")
