import serial
import time
from supabase import create_client
import cv2
from ultralytics import YOLO
import pytesseract

# Initialize Supabase
SUPABASE_URL = "https://ipmshfkymnflueddojcw.supabase.co"
SUPABASE_API_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImlwbXNoZmt5bW5mbHVlZGRvamN3Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3MzE5NDU0NzAsImV4cCI6MjA0NzUyMTQ3MH0.CIAqAEJ_aV5OIbyCKEShSljutfYdmGR67tvpVgO1gUc"
supabase = create_client(SUPABASE_URL, SUPABASE_API_KEY)

# Initialize Serial Connection to Arduino (adjust COM port if necessary)
arduino = serial.Serial('COM5', 9600, timeout=1)

# Load YOLO model for number plate detection
model_plate = YOLO(r"D:\Integration\Number Plate Detection\roboflow\runs\detect\train\weights\best.pt")  # Replace with your trained model path

# Function to send message to LCD
def send_message_to_lcd(message):
    if arduino.isOpen():
        arduino.write(f"LCD:{message}\n".encode())  # Send message to Arduino for display on LCD
        print(f"Sent to LCD: {message}")

# Function to insert detected plate into the test table
def insert_to_test_table(plate_text):
    response = supabase.table("test").insert({"plate": plate_text, "timestamp": "NOW()"}).execute()
    if response.data:
        print(f"Plate '{plate_text}' inserted successfully into the test table.")
    else:
        print(f"Failed to insert plate '{plate_text}': {response.get('error', 'Unknown Error')}")

# Function to update parking spot status in Supabase
def update_parking_status(slot_number, status):
    response = supabase.table("parking_spots").update({"status": status, "timestamp": "NOW()"}).eq("slot_number", slot_number).execute()
    if response.data:
        print(f"Slot {slot_number} status updated to: {status}")
    else:
        print(f"Failed to update Slot {slot_number}: {response.get('error', 'Unknown Error')}")

# Function to detect number plates using the YOLO model
def detect_number_plate():
    cap_plate = cv2.VideoCapture(0)  # Use webcam for number plate detection

    while True:
        ret, frame = cap_plate.read()
        if not ret:
            print("Failed to capture frame from webcam.")
            break

        # YOLO detection for number plates
        results_plate = model_plate.predict(source=frame, show=True, conf=0.5)

        for result in results_plate:
            for box in result.boxes:
                x1, y1, x2, y2 = map(int, box.xyxy[0])  # Bounding box for detected plate
                cropped_plate = frame[y1:y2, x1:x2]     # Crop the detected number plate

                # OCR to extract text from the cropped plate
                plate_text = pytesseract.image_to_string(cropped_plate, config="--psm 7").strip()
                if plate_text:
                    print(f"Detected Plate: {plate_text}")

                    # Insert the plate into the test table and stop the camera
                    insert_to_test_table(plate_text)

                    # Send message to LCD
                    send_message_to_lcd(f"Plate: {plate_text}")

                    # Stop the camera
                    cap_plate.release()
                    cv2.destroyAllWindows()
                    return  # Exit the function

        # Exit loop on 'q' key press
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    # Release resources
    cap_plate.release()
    cv2.destroyAllWindows()

# Function to listen to Arduino for parking spot updates
def listen_to_arduino():
    while True:
        if arduino.in_waiting > 0:
            sensor_data = arduino.readline().decode('utf-8').strip()
            print(f"Received from Arduino: {sensor_data}")
            if "Slot 1" in sensor_data or "Slot 2" in sensor_data:
                if "Slot 1 is occupied" in sensor_data:
                    update_parking_status(1, "Occupied")
                elif "Slot 1 is available" in sensor_data:
                    update_parking_status(1, "Available")
                if "Slot 2 is occupied" in sensor_data:
                    update_parking_status(2, "Occupied")
                elif "Slot 2 is available" in sensor_data:
                    update_parking_status(2, "Available")

# Main function to manage the program flow
if __name__ == "__main__":
    # Step 1: Display message "Hello Guest" on LCD via Arduino
    send_message_to_lcd("Hello Guest")

    # Step 2: Run number plate detection (camera and OCR)
    detect_number_plate()

    # Step 3: Listen to Arduino for parking slot updates
    listen_to_arduino()
