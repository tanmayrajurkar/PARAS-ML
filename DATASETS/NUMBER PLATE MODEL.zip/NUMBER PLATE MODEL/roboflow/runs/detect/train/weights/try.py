import serial
import cv2
import pytesseract
from ultralytics import YOLO
from supabase import create_client

# Initialize Supabase
SUPABASE_URL = "https://ipmshfkymnflueddojcw.supabase.co"
SUPABASE_API_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImlwbXNoZmt5bW5mbHVlZGRvamN3Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3MzE5NDU0NzAsImV4cCI6MjA0NzUyMTQ3MH0.CIAqAEJ_aV5OIbyCKEShSljutfYdmGR67tvpVgO1gUc"
supabase = create_client(SUPABASE_URL, SUPABASE_API_KEY)

# Initialize Serial Connection to Arduino
arduino = serial.Serial('COM5', 9600, timeout=1)  # Replace with your Arduino port

# Load YOLO model for number plate detection
model_plate = YOLO(r"D:\Integration\NUMBER PLATE MODEL\roboflow\runs\detect\train\weights\best.pt")

# Function to insert detected plate into the test table
def insert_to_test_table(plate_text):
    response = supabase.table("test").insert({"plate": plate_text, "timestamp": "NOW()"}).execute()
    if response.data:
        print(f"Plate '{plate_text}' inserted successfully into the test table.")
    else:
        print(f"Failed to insert plate '{plate_text}': {response.get('error', 'Unknown Error')}")

# Function to update parking spot status in Supabase
def update_parking_status(slot_number, status):
    response = supabase.table("parking_spots").update({"status": status, "timestamp": "NOW()"}).eq("slot_number", slot_number).execute()
    if response.data:
        print(f"Slot {slot_number} status updated to: {status}")
    else:
        print(f"Failed to update Slot {slot_number}: {response.get('error', 'Unknown Error')}")

# Function to detect number plates
def detect_number_plate():
    cap_plate = cv2.VideoCapture(0)  # Use webcam 0 for number plate detection
    while True:
        ret, frame = cap_plate.read()
        if not ret:
            print("Failed to capture frame from webcam.")
            break

        # YOLO detection for number plates
        results_plate = model_plate.predict(source=frame, show=True, conf=0.5)

        for result in results_plate:
            for box in result.boxes:
                x1, y1, x2, y2 = map(int, box.xyxy[0])  # Bounding box for detected plate
                cropped_plate = frame[y1:y2, x1:x2]     # Crop the detected number plate

                # OCR to extract text from the cropped plate
                plate_text = pytesseract.image_to_string(cropped_plate, config="--psm 7").strip()
                if plate_text:
                    print(f"Detected Plate: {plate_text}")
                    insert_to_test_table(plate_text)
                    
                    cap_plate.release()
                    cv2.destroyAllWindows()
                    return plate_text  # Return detected plate text

        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    cap_plate.release()
    cv2.destroyAllWindows()
    return None

# Function to listen to Arduino
def listen_to_arduino():
    while True:
        if arduino.in_waiting > 0:
            sensor_data = arduino.readline().decode('utf-8').strip()
            print(f"Received from Arduino: {sensor_data}")

            if "Slot 1" in sensor_data:
                if "Slot 1 is occupied" in sensor_data:
                    update_parking_status(1, "Occupied")
                    print("Car has been parked at spot 1")
                elif "Slot 1 is available" in sensor_data:
                    update_parking_status(1, "Available")
            elif "Slot 2" in sensor_data:
                if "Slot 2 is occupied" in sensor_data:
                    update_parking_status(2, "Occupied")
                    print("Car has been parked at spot 2")
                elif "Slot 2 is available" in sensor_data:
                    update_parking_status(2, "Available")

# Main function
if __name__ == "__main__":
    # Step 1: Detect number plate
    detected_plate = detect_number_plate()
    if detected_plate:
        print(f"Number plate detected: {detected_plate}")
    else:
        print("No number plate detected.")

    # Step 2: Listen to Arduino for parking slot updates
    listen_to_arduino()
