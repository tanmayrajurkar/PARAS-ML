import cv2
from ultralytics import YOLO
import pytesseract
from supabase import create_client

# Initialize Supabase
SUPABASE_URL = "https://ipmshfkymnflueddojcw.supabase.co"
SUPABASE_API_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImlwbXNoZmt5bW5mbHVlZGRvamN3Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3MzE5NDU0NzAsImV4cCI6MjA0NzUyMTQ3MH0.CIAqAEJ_aV5OIbyCKEShSljutfYdmGR67tvpVgO1gUc"
supabase = create_client(SUPABASE_URL, SUPABASE_API_KEY)

# Load YOLO model for number plate detection
model = YOLO(r"D:\Integration\Number Plate Detection\roboflow\runs\detect\train\weights\best.pt")  # Update path

# Function to store number plate data in Supabase
def store_plate_data(plate_text):
    """
    Stores detected number plate text in the Supabase database.
    Args:
        plate_text (str): Detected number plate text.
    """
    data = {
        "plate": plate_text,
        "timestamp": "NOW()"
    }
    response = supabase.table("test").insert(data).execute()

    # if response.status_code == 201:
    #     print(f"Data stored successfully: {data}")
    # else:
    #     print(f"Failed to store data: {response}")

# Main function to detect number plates
def detect_number_plate():
    cap = cv2.VideoCapture(0)  # Use webcam (set to 0 or another ID if multiple cameras)
    detected_plates = set()   # Store unique plates to avoid duplicates

    while True:
        ret, frame = cap.read()
        if not ret:
            print("Failed to capture frame from webcam.")
            break

        # YOLO detection for number plates
        results = model.predict(source=frame, show=True, conf=0.5)
        for result in results:
            for box in result.boxes:
                x1, y1, x2, y2 = map(int, box.xyxy[0])  # Extract bounding box coordinates
                cropped_plate = frame[y1:y2, x1:x2]     # Crop the detected number plate

                # OCR to extract text from the cropped plate
                plate_text = pytesseract.image_to_string(cropped_plate, config="--psm 7").strip()
                if plate_text and plate_text not in detected_plates:
                    detected_plates.add(plate_text)
                    print(f"Detected Plate: {plate_text}")

                    # Store the detected plate in the database
                    store_plate_data(plate_text)

        # Exit loop on 'q' key press
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    # Release resources
    cap.release()
    cv2.destroyAllWindows()

# Run the function
detect_number_plate()
