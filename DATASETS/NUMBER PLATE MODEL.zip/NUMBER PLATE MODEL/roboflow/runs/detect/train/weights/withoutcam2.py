import serial
import time
import cv2
from ultralytics import YOLO
from supabase import create_client
import pytesseract

# Initialize Supabase
SUPABASE_URL = "https://ipmshfkymnflueddojcw.supabase.co"
SUPABASE_API_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImlwbXNoZmt5bW5mbHVlZGRvamN3Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3MzE5NDU0NzAsImV4cCI6MjA0NzUyMTQ3MH0.CIAqAEJ_aV5OIbyCKEShSljutfYdmGR67tvpVgO1gUc"
supabase = create_client(SUPABASE_URL, SUPABASE_API_KEY)

# Initialize Serial Connection to Arduino
arduino = serial.Serial('COM5', 9600, timeout=1)  # Replace with your Arduino port

# Load YOLO model for number plate detection
model_plate = YOLO(r"D:\Integration\Number Plate Detection\roboflow\runs\detect\train\weights\best.pt")  # Replace with your trained model path

# Function to update parking spot status in Supabase (Slot 1 and Slot 2)
def update_parking_status(slot_number, status):
    # Update the existing entry in the table based on slot number
    response = supabase.table("parking_spots").update({"status": status, "timestamp": "NOW()"}).eq("slot_number", slot_number).execute()
    print(f"Updated Slot {slot_number} to {status}")

# Function to read parking spot status from Arduino (Sensor 1 and Sensor 2) and update the table
def get_parking_spot_status_and_update():
    arduino.flushInput()  # Clear the buffer

    # Read the sensor data from Arduino
    sensor_data = arduino.readline().decode('utf-8').strip()
    
    # Debug: Print the sensor data
    print(f"Received sensor data from Arduino: {sensor_data}")
    
    # Parse the sensor data for Slot 1 and Slot 2
    if "SENSOR1:" in sensor_data and "SENSOR2:" in sensor_data:
        sensor1_status = sensor_data.split(',')[0].split(':')[1].strip()
        sensor2_status = sensor_data.split(',')[1].split(':')[1].strip()
        
        # Update the parking spot status in Supabase
        update_parking_status(1, sensor1_status)
        update_parking_status(2, sensor2_status)
    else:
        print("Invalid sensor data received")

# Main function to detect number plates and check parking spot status
def detect_number_plate_and_check_parking():
    cap_plate = cv2.VideoCapture(0)  # Use webcam for number plate detection

    while True:
        ret, frame = cap_plate.read()
        if not ret:
            print("Failed to capture frame from webcam for plate detection.")
            break

        # YOLO detection for number plates
        results_plate = model_plate.predict(source=frame, show=True, conf=0.5)
        plate_detected_in_slot_1 = False
        plate_detected_in_slot_2 = False
        
        for result in results_plate:
            for box in result.boxes:
                x1, y1, x2, y2 = map(int, box.xyxy[0])  # Bounding box for detected plate
                cropped_plate = frame[y1:y2, x1:x2]     # Crop the detected number plate

                # OCR to extract text from the cropped plate
                plate_text = pytesseract.image_to_string(cropped_plate, config="--psm 7").strip()
                if plate_text:
                    # Assuming the first plate belongs to slot 1 and second to slot 2 (for simplicity)
                    car_center_x = (x1 + x2) // 2
                    if car_center_x < frame.shape[1] // 2:  # Slot 1 is on the left
                        plate_detected_in_slot_1 = True
                    else:  # Slot 2 is on the right
                        plate_detected_in_slot_2 = True
                    
                    print(f"Detected Plate: {plate_text}")

        # Update parking status for Slot 1
        if plate_detected_in_slot_1:
            update_parking_status(1, "Occupied")
        else:
            update_parking_status(1, "Available")
        
        # Update parking status for Slot 2
        if plate_detected_in_slot_2:
            update_parking_status(2, "Occupied")
        else:
            update_parking_status(2, "Available")
        
        # Get and update the parking spot status from the sensors (Arduino)
        get_parking_spot_status_and_update()
        
        # Exit loop on 'q' key press
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    # Release resources
    cap_plate.release()
    cv2.destroyAllWindows()

# Run the function
detect_number_plate_and_check_parking()
