import cv2
from ultralytics import YOLO
import pytesseract

# Initialize YOLO model
# model = YOLO("best.pt")  # Ensure this is the correct path to your model
model = YOLO(r"D:\Integration\roboflow\runs\detect\train\weights\best.pt")

# Initialize webcam
cap = cv2.VideoCapture(0)

# Initialize a set to store unique plates
detected_plates = set()

# Open a file to store plates
with open("D:\Integration\roboflow\runs\detect\train\weights\number_plates.txt", "w") as file:
    file.write("Extracted Number Plates:\n")

while True:
    ret, frame = cap.read()
    if not ret:
        print("Failed to grab frame. Exiting...")
        break

    # Perform inference on the frame
    results = model.predict(source=frame, show=True, conf=0.5)

    # Loop through detected objects
    for result in results:
        boxes = result.boxes  # Detected boxes
        for box in boxes:
            # Extract bounding box coordinates
            x1, y1, x2, y2 = map(int, box.xyxy[0])  # Convert to integers
            cropped_plate = frame[y1:y2, x1:x2]  # Crop the detected region

            # Apply OCR using Tesseract
            plate_text = pytesseract.image_to_string(cropped_plate, config="--psm 7")
            plate_text = plate_text.strip()  # Clean up whitespace

            # Avoid duplicates and save to file
            if plate_text not in detected_plates and plate_text:
                detected_plates.add(plate_text)
                print(f"Detected Plate: {plate_text}")
                with open("number_plates.txt", "a") as file:
                    file.write(f"{plate_text}\n")

    # Break the loop with 'q'
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# Release resources
cap.release()
cv2.destroyAllWindows()



