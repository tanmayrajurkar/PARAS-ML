import cv2
from ultralytics import YOLO
import pytesseract
from supabase import create_client
import serial
import time

# Initialize Supabase
SUPABASE_URL = "https://ipmshfkymnflueddojcw.supabase.co"
SUPABASE_API_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImlwbXNoZmt5bW5mbHVlZGRvamN3Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3MzE5NDU0NzAsImV4cCI6MjA0NzUyMTQ3MH0.CIAqAEJ_aV5OIbyCKEShSljutfYdmGR67tvpVgO1gUc"
supabase = create_client(SUPABASE_URL, SUPABASE_API_KEY)

# Initialize Serial Connection to Arduino
arduino = serial.Serial('COM5', 9600, timeout=1)  # Replace COM_PORT with your Arduino port

# Load YOLO model for number plate detection
model = YOLO(r"D:\Integration\Number Plate Detection\roboflow\runs\detect\train\weights\best.pt")  # Update path

# Function to store number plate data in Supabase
def store_plate_data(plate_text):
    """
    Stores detected number plate text in the Supabase database.
    Args:
        plate_text (str): Detected number plate text.
    """
    data = {
        "plate": plate_text,
        "timestamp": "NOW()"
    }
    response = supabase.table("test").insert(data).execute()

# Function to read parking spot status from Arduino
def get_parking_spot_status():
    arduino.flushInput()  # Clear the buffer
    arduino.write(b"GET_STATUS\n")  # Send request to Arduino for status
    time.sleep(1)  # Wait for Arduino to process and respond
    status = arduino.readline().decode('utf-8').strip()  # Read and decode Arduino response
    return status

# Main function to detect number plates and check parking spot status
def detect_number_plate_and_car():
    cap_plate = cv2.VideoCapture(0)  # Use webcam for number plate detection (Camera 1)
    cap_car = cv2.VideoCapture(1)    # Use second webcam for car detection (Camera 2)

    if not cap_plate.isOpened():
        print("Error: Could not open plate detection camera.")
        return
    
    if not cap_car.isOpened():
        print("Error: Could not open car detection camera.")
        return
    
    detected_plates = set()   # Store unique plates to avoid duplicates

    while True:
        # 1. Number Plate Detection (Camera 1)
        ret, frame = cap_plate.read()
        if not ret:
            print("Failed to capture frame from webcam for plate detection.")
            break

        # YOLO detection for number plates
        results = model.predict(source=frame, show=True, conf=0.5)
        for result in results:
            for box in result.boxes:
                x1, y1, x2, y2 = map(int, box.xyxy[0])  # Extract bounding box coordinates
                cropped_plate = frame[y1:y2, x1:x2]     # Crop the detected number plate

                # OCR to extract text from the cropped plate
                plate_text = pytesseract.image_to_string(cropped_plate, config="--psm 7").strip()
                if plate_text and plate_text not in detected_plates:
                    detected_plates.add(plate_text)
                    print(f"Detected Plate: {plate_text}")

                    # Store the detected plate in the database
                    store_plate_data(plate_text)
                    
                    # Proceed to car detection after plate detection is done
                    break  # Exit after detecting and storing the plate

        # Exit loop on 'q' key press
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

        # 2. Car Detection and Parking Spot Status (Camera 2)
        # Wait until the plate has been detected and stored
        if detected_plates:
            ret, frame_car = cap_car.read()
            if not ret:
                print("Failed to capture frame from webcam for car detection.")
                break

            # Here you can add your car detection logic (e.g., using YOLO for car detection)

            # Simulate checking parking spot status via Arduino (i.e., the car is parked)
            parking_status = get_parking_spot_status()
            print(f"Parking Spot Status: {parking_status}")

            # Here you can update the database or take actions based on the car detection and parking status

            # Optionally reset detected plates after processing
            detected_plates.clear()  # Reset detected plates after processing one car

        # Prevent an infinite loop that consumes resources if no plate is detected
        time.sleep(1)  # Add a small delay before the next iteration

    # Release resources
    cap_plate.release()
    cap_car.release()
    cv2.destroyAllWindows()

# Run the function
detect_number_plate_and_car()
