import cv2
from ultralytics import YOLO
import pytesseract
from supabase import create_client
import serial
import time

# Supabase configuration
SUPABASE_URL = "https://ipmshfkymnflueddojcw.supabase.co"
SUPABASE_API_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImlwbXNoZmt5bW5mbHVlZGRvamN3Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3MzE5NDU0NzAsImV4cCI6MjA0NzUyMTQ3MH0.CIAqAEJ_aV5OIbyCKEShSljutfYdmGR67tvpVgO1gUc"
supabase = create_client(SUPABASE_URL, SUPABASE_API_KEY)

# Serial configuration
arduino = serial.Serial('COM5', 9600, timeout=1)  # Replace with your Arduino port

# Load YOLO model for number plate detection
model = YOLO(r"D:\Integration\Number Plate Detection\roboflow\runs\detect\train\weights\best.pt")  # Update path

def store_plate_data(plate_text):
    """
    Stores detected number plate text in the Supabase database.
    Args:
        plate_text (str): Detected number plate text.
    """
    data = {"plate": plate_text, "timestamp": "NOW()"}
    response = supabase.table("plates").insert(data).execute()
    print(f"Stored Plate: {plate_text}")

def update_parking_status(slot_number, status):
    """
    Update the status of a parking spot in the Supabase database.
    Args:
        slot_number (int): Parking slot number (1 or 2).
        status (str): Status of the parking spot ('Occupied' or 'Available').
    """
    data = {"slot_number": slot_number, "status": status}
    response = supabase.table("parking_spots").insert(data).execute()
    print(f"Updated Slot {slot_number}: {status}")

def get_parking_spot_status():
    """
    Reads parking spot status from Arduino.
    Returns:
        dict: Statuses of parking spots (e.g., {"S1": "Occupied", "S2": "Available"}).
    """
    arduino.flushInput()
    arduino.write(b"GET_STATUS\n")
    time.sleep(1)
    status_data = arduino.readline().decode('utf-8').strip()
    print(f"Parking Status from Arduino: {status_data}")
    status = {}
    try:
        for entry in status_data.split(';'):
            if entry:
                slot, state = entry.split(':')
                status[slot] = state
    except ValueError:
        print("Error parsing parking status.")
    return status

def detect_number_plate():
    """
    Detects number plates using the YOLO model and OCR.
    Returns:
        str: Detected number plate text.
    """
    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        print("Error: Could not open webcam.")
        return None

    detected_plate = None
    while True:
        ret, frame = cap.read()
        if not ret:
            print("Failed to capture frame.")
            break

        results = model.predict(source=frame, show=True, conf=0.5)
        for result in results:
            for box in result.boxes:
                x1, y1, x2, y2 = map(int, box.xyxy[0])
                cropped_plate = frame[y1:y2, x1:x2]

                plate_text = pytesseract.image_to_string(cropped_plate, config="--psm 7").strip()
                if plate_text:
                    detected_plate = plate_text
                    print(f"Detected Plate: {detected_plate}")
                    store_plate_data(detected_plate)
                    break

        # Break if a plate is detected
        if detected_plate:
            break

        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    cap.release()
    cv2.destroyAllWindows()
    return detected_plate

def main():
    print("Starting system...")

    # Step 1: Detect Number Plate
    print("Detecting number plate...")
    plate_text = detect_number_plate()
    if not plate_text:
        print("No plate detected. Exiting...")
        return

    # Step 2: Check Parking Spot Status
    print("Checking parking spot status...")
    parking_status = get_parking_spot_status()
    for slot, status in parking_status.items():
        slot_number = int(slot[1])  # Extract slot number (e.g., "S1" -> 1)
        update_parking_status(slot_number, status)

# if _name_ == "_main_":
    main()