# NumberPlateDetection > 2024-11-20 9:22pm
https://universe.roboflow.com/university-cjsad/numberplatedetection-yorum

Provided by a Roboflow user
License: CC BY 4.0

