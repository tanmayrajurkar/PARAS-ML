# car detection > 2024-12-11 10:53pm
https://universe.roboflow.com/home-n5e1v/car-detection-ye0td

Provided by a Roboflow user
License: CC BY 4.0

